# Cypher FX — Unified Steps 1–10

frontend/ = Next.js website and admin UI
backend/ = secure server/API and integrations
supabase/ = PostgreSQL migrations, RLS and database layer
powerbi/ = reporting views and DAX guidance
tests/ = unit, integration, security and E2E tests
docs/ = deployment and operations documentation

IMPORTANT: This is the consolidated development scaffold. Real-money launch requires verified Safaricom Daraja production integration, an approved trading/execution provider, reconciliation, security review and applicable legal/regulatory approval.

Local:
cd frontend
npm install
copy .env.example .env.local
npm run dev

Frontend: http://localhost:3000

Backend:
cd backend
npm install
copy .env.example .env
npm run dev

Backend health: http://localhost:4000/api/health
