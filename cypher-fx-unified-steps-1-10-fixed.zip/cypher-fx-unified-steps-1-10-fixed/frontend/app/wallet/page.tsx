import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function Wallet() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: realAccount } = await supabase
    .from("accounts")
    .select("id,available_balance,currency")
    .eq("user_id", user.id)
    .eq("account_type", "REAL")
    .maybeSingle();

  const balanceLabel = realAccount
    ? `${realAccount.currency} ${Number(realAccount.available_balance).toLocaleString(undefined, {
        minimumFractionDigits: 2,
      })}`
    : "No real account yet";

  return (
    <main className="container">
      <h1>Wallet</h1>
      <div className="card">
        <h2>{balanceLabel}</h2>
      </div>
      <Link className="btn" href={`/deposits${realAccount ? `?accountId=${realAccount.id}` : ""}`}>
        Deposit
      </Link>
      <Link className="btn" href={`/withdrawals${realAccount ? `?accountId=${realAccount.id}` : ""}`}>
        Withdraw
      </Link>
    </main>
  );
}
