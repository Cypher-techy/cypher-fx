"use client";

import { useState } from "react";
import { isValidPositiveAmount, isValidPhone } from "@/lib/security/validation";
import { apiFetch } from "@/lib/api";

export default function Withdrawals({
  searchParams,
}: {
  searchParams: { accountId?: string };
}) {
  const [amount, setAmount] = useState("");
  const [phone, setPhone] = useState("");
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setStatus(null);

    if (!searchParams.accountId) {
      setError("No account selected. Open Withdraw from the Wallet page.");
      return;
    }
    if (!isValidPositiveAmount(amount)) {
      setError("Enter a valid amount greater than 0.");
      return;
    }
    if (!isValidPhone(phone)) {
      setError("Enter a valid M-PESA phone number (format 2547XXXXXXXX).");
      return;
    }

    setIsLoading(true);
    try {
      await apiFetch("/api/withdrawals", {
        method: "POST",
        body: JSON.stringify({ accountId: searchParams.accountId, amount: Number(amount), phone }),
      });
      setStatus("Withdrawal requested. It needs admin approval before payout.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Withdrawal request failed");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="container">
      <h1>Withdraw</h1>
      <form className="card" onSubmit={handleSubmit}>
        <label htmlFor="amount">Amount (KES)</label>
        <input
          id="amount"
          name="amount"
          type="number"
          min="1"
          step="0.01"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
        <label htmlFor="phone">M-PESA phone</label>
        <input
          id="phone"
          name="phone"
          type="tel"
          placeholder="2547XXXXXXXX"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
        />
        {error ? <p role="alert" className="muted">{error}</p> : null}
        {status ? <p className="muted">{status}</p> : null}
        <button type="submit" disabled={isLoading}>
          {isLoading ? "Requesting…" : "Request withdrawal"}
        </button>
      </form>
    </main>
  );
}
