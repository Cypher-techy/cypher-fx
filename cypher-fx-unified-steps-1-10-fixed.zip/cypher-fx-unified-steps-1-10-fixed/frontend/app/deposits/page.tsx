"use client";

import { useState } from "react";
import { isValidPositiveAmount, isValidPhone } from "@/lib/security/validation";
import { apiFetch } from "@/lib/api";

export default function Deposits({
  searchParams,
}: {
  searchParams: { accountId?: string };
}) {
  const [amount, setAmount] = useState("");
  const [phone, setPhone] = useState("");
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setStatus(null);

    if (!searchParams.accountId) {
      setError("No account selected. Open Deposit from the Wallet page.");
      return;
    }
    if (!isValidPositiveAmount(amount)) {
      setError("Enter a valid amount greater than 0.");
      return;
    }
    if (!isValidPhone(phone)) {
      setError("Enter a valid M-PESA phone number (format 2547XXXXXXXX).");
      return;
    }

    setIsLoading(true);
    try {
      await apiFetch("/api/mpesa/stkpush", {
        method: "POST",
        body: JSON.stringify({ accountId: searchParams.accountId, amount: Number(amount), phone }),
      });
      setStatus("STK push requested. Check your phone to complete the payment.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Deposit request failed");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="container">
      <h1>Deposit</h1>
      <form className="card" onSubmit={handleSubmit}>
        <label htmlFor="amount">Amount (KES)</label>
        <input
          id="amount"
          name="amount"
          type="number"
          min="1"
          step="0.01"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
        <label htmlFor="phone">M-PESA phone</label>
        <input
          id="phone"
          name="phone"
          type="tel"
          placeholder="2547XXXXXXXX"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          required
        />
        {error ? <p role="alert" className="muted">{error}</p> : null}
        {status ? <p className="muted">{status}</p> : null}
        <button type="submit" disabled={isLoading}>
          {isLoading ? "Requesting…" : "Request STK"}
        </button>
        <p className="muted">The M-PESA PIN is entered only in the Safaricom prompt.</p>
      </form>
    </main>
  );
}
