import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function Analytics() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  // This page previously had no authorization check at all — any signed-in
  // user (or, with middleware also missing a check, any visitor) could
  // open it. profiles.role is only ever set by the backend service role.
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single();

  if (profile?.role !== "admin") redirect("/dashboard");

  return (
    <main className="container">
      <h1>Power BI Analytics</h1>
      <a className="btn" href={process.env.NEXT_PUBLIC_POWERBI_EXECUTIVE_URL || "#"}>
        Executive report
      </a>
      <a className="btn" href={process.env.NEXT_PUBLIC_POWERBI_TRADING_URL || "#"}>
        Trading report
      </a>
    </main>
  );
}
