import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function Dashboard() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  // RLS (accounts_self_select) restricts this to the caller's own rows,
  // so this is safe to query directly with the user's session.
  const { data: accounts } = await supabase
    .from("accounts")
    .select("id,account_type,available_balance,currency")
    .eq("user_id", user.id);

  const demoAccount = accounts?.find((a) => a.account_type === "DEMO");
  const realAccount = accounts?.find((a) => a.account_type === "REAL");

  return (
    <main className="container">
      <h1>Dashboard</h1>
      <div className="grid">
        <div className="card">
          <h2>Demo Balance</h2>
          <p>
            {demoAccount
              ? `KSh ${Number(demoAccount.available_balance).toLocaleString()}`
              : "No demo account yet"}
          </p>
        </div>
        <div className="card">
          <h2>Real Wallet</h2>
          <p>
            {realAccount
              ? `KSh ${Number(realAccount.available_balance).toLocaleString()}`
              : "No real account yet"}
          </p>
        </div>
      </div>
      <Link className="btn" href={`/demo${demoAccount ? `?accountId=${demoAccount.id}` : ""}`}>
        Demo Trading
      </Link>
      <Link className="btn" href={`/trading${realAccount ? `?accountId=${realAccount.id}` : ""}`}>
        Trading
      </Link>
      <Link className="btn" href="/wallet">
        Wallet
      </Link>
    </main>
  );
}
