"use client";

import { useState } from "react";
import { isValidPositiveAmount, isValidSymbol } from "@/lib/security/validation";
import { apiFetch } from "@/lib/api";

export default function Trading({
  searchParams,
}: {
  searchParams: { accountId?: string };
}) {
  const [symbol, setSymbol] = useState("");
  const [quantity, setQuantity] = useState("");
  const [side, setSide] = useState<"BUY" | "SELL">("BUY");
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  async function placeOrder(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setStatus(null);

    if (!searchParams.accountId) {
      setError("No account selected. Open Trading from the Dashboard.");
      return;
    }
    const upperSymbol = symbol.toUpperCase();
    if (!isValidSymbol(upperSymbol)) {
      setError("Enter a valid symbol, e.g. EURUSD.");
      return;
    }
    if (!isValidPositiveAmount(quantity)) {
      setError("Enter a valid quantity greater than 0.");
      return;
    }

    setIsLoading(true);
    try {
      const result = await apiFetch("/api/trading/orders", {
        method: "POST",
        body: JSON.stringify({
          accountId: searchParams.accountId,
          symbol: upperSymbol,
          side,
          quantity: Number(quantity),
          // Real-account orders have no live price feed configured in this
          // scaffold; a real integration would source this from market data
          // rather than accepting a client-submitted price.
          requestedPrice: 1,
        }),
      });
      setStatus(result.status ?? "Order submitted.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Order failed");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="container">
      <h1>Trading</h1>
      <form className="card" onSubmit={placeOrder}>
        <label htmlFor="symbol">Symbol</label>
        <input
          id="symbol"
          name="symbol"
          placeholder="EURUSD"
          value={symbol}
          onChange={(e) => setSymbol(e.target.value)}
          required
        />
        <label htmlFor="quantity">Quantity</label>
        <input
          id="quantity"
          name="quantity"
          type="number"
          min="0.01"
          step="0.01"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
          required
        />
        <div>
          <button type="button" onClick={() => setSide("BUY")} disabled={side === "BUY"}>
            BUY
          </button>
          <button type="button" onClick={() => setSide("SELL")} disabled={side === "SELL"}>
            SELL
          </button>
        </div>
        {error ? <p role="alert" className="muted">{error}</p> : null}
        {status ? <p className="muted">{status}</p> : null}
        <button type="submit" disabled={isLoading}>
          {isLoading ? "Placing order…" : `Place ${side} order`}
        </button>
      </form>
    </main>
  );
}
