"use client";

import { useState } from "react";
import { apiFetch } from "@/lib/api";

export default function Demo({
  searchParams,
}: {
  searchParams: { accountId?: string };
}) {
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  async function trade(side: "BUY" | "SELL") {
    setError(null);
    setStatus(null);

    if (!searchParams.accountId) {
      setError("No demo account selected. Open Demo from the Dashboard.");
      return;
    }

    setIsLoading(true);
    try {
      // A fixed demo symbol/price/quantity keeps this one-tap, since this
      // screen exists to let a new user feel a fill immediately. The
      // account must be type DEMO — the backend fills it instantly and
      // will not do this for a REAL account.
      const result = await apiFetch("/api/trading/orders", {
        method: "POST",
        body: JSON.stringify({
          accountId: searchParams.accountId,
          symbol: "EURUSD",
          side,
          quantity: 1,
          requestedPrice: 1.085,
        }),
      });
      setStatus(`${side} filled at demo price ${result.order?.filled_price ?? "—"}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Demo trade failed");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="container">
      <h1>Demo Trading</h1>
      <div className="card">
        <p className="muted">Simulated prices and paper trades only. No real market execution.</p>
        <button onClick={() => trade("BUY")} disabled={isLoading}>
          BUY
        </button>
        <button onClick={() => trade("SELL")} disabled={isLoading}>
          SELL
        </button>
        {error ? <p role="alert" className="muted">{error}</p> : null}
        {status ? <p className="muted">{status}</p> : null}
      </div>
    </main>
  );
}
