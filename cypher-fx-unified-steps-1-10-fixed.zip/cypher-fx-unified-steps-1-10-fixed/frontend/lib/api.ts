import { createClient } from "@/lib/supabase/client";

/**
 * Calls the backend API with the current Supabase session's access token
 * attached as a Bearer header — every backend route added in this fix
 * (mpesa, trading, withdrawals) requires requireAuth, so calls made
 * without this would all get a 401.
 */
export async function apiFetch(path: string, init: RequestInit = {}) {
  const supabase = createClient();
  const {
    data: { session },
  } = await supabase.auth.getSession();

  const baseUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

  const res = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(session ? { Authorization: `Bearer ${session.access_token}` } : {}),
      ...init.headers,
    },
  });

  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(body?.error || `Request failed (${res.status})`);
  }
  return body;
}
