-- Ledger boundary (backend/src/services/wallet/ledger.ts) implemented as
-- atomic Postgres functions rather than read-then-write app code, so a
-- balance update can never race with another request for the same account.
-- Callable only by the service-role backend, never directly by a client.

create or replace function public.credit_account_balance(p_account_id uuid, p_amount numeric)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if p_amount <= 0 then
    raise exception 'credit amount must be positive';
  end if;

  update public.accounts
  set available_balance = available_balance + p_amount,
      updated_at = now()
  where id = p_account_id;

  if not found then
    raise exception 'account % not found', p_account_id;
  end if;
end;
$$;

-- Moves funds from available_balance into locked_balance atomically, and
-- fails (returns false) rather than overdrawing if the balance is
-- insufficient at the moment of the update — closes the check-then-act
-- race a plain "select balance, then insert withdrawal" would have.
create or replace function public.lock_withdrawal_funds(p_account_id uuid, p_amount numeric)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  updated_rows int;
begin
  if p_amount <= 0 then
    raise exception 'withdrawal amount must be positive';
  end if;

  update public.accounts
  set available_balance = available_balance - p_amount,
      locked_balance = locked_balance + p_amount,
      updated_at = now()
  where id = p_account_id
    and available_balance >= p_amount;

  get diagnostics updated_rows = row_count;
  return updated_rows = 1;
end;
$$;

-- Compensating action for lock_withdrawal_funds — used when a withdrawal
-- row fails to insert after funds were already locked, so they don't get
-- stranded in locked_balance with no corresponding request.
create or replace function public.unlock_withdrawal_funds(p_account_id uuid, p_amount numeric)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.accounts
  set available_balance = available_balance + p_amount,
      locked_balance = greatest(locked_balance - p_amount, 0),
      updated_at = now()
  where id = p_account_id;
end;
$$;

revoke execute on function public.credit_account_balance(uuid, numeric) from public, anon, authenticated;
revoke execute on function public.lock_withdrawal_funds(uuid, numeric) from public, anon, authenticated;
revoke execute on function public.unlock_withdrawal_funds(uuid, numeric) from public, anon, authenticated;
grant execute on function public.credit_account_balance(uuid, numeric) to service_role;
grant execute on function public.lock_withdrawal_funds(uuid, numeric) to service_role;
grant execute on function public.unlock_withdrawal_funds(uuid, numeric) to service_role;
