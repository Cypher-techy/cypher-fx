-- Nothing created a public.profiles row or any public.accounts rows when a
-- user signed up via supabase.auth.signUp() — the dashboard and wallet
-- pages would show "no account yet" forever for every real user. This
-- trigger creates a profile plus one DEMO account (seeded with paper
-- funds) and one REAL account (starts at 0, real deposits only) whenever
-- a new row appears in auth.users.

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email);

  insert into public.accounts (user_id, account_type, currency, available_balance)
  values (new.id, 'DEMO', 'KES', 100000);

  insert into public.accounts (user_id, account_type, currency, available_balance)
  values (new.id, 'REAL', 'KES', 0);

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
