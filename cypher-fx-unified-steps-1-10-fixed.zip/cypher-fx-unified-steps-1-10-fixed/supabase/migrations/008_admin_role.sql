-- profiles.role did not exist, so requireAdmin (backend/src/middleware/admin.ts)
-- had nothing to check. Defaults to 'user'; only a service-role connection
-- (the backend) can change it — no RLS update policy is granted here on
-- purpose, so a user's own client session can never grant itself admin.
alter table public.profiles
  add column if not exists role text not null default 'user' check (role in ('user', 'admin'));
