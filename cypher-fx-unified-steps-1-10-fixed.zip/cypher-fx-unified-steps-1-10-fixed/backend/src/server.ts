import "dotenv/config";
import express, { NextFunction, Request, Response } from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { withdrawalsRouter } from "./routes/withdrawals";
import { mpesaRouter } from "./routes/mpesa";
import { tradingRouter } from "./routes/trading";

const app = express();
const port = Number(process.env.PORT || 4000);

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || "http://localhost:3000" }));
app.use(express.json());

// Money-moving and order-placement endpoints get a tighter limit than the
// rest of the API, per the security checklist's rate-limiting requirement.
const financialLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20 });

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "cypher-fx-backend" }));

// These three routers previously existed but were never mounted here, so
// none of their routes were reachable — /api/withdrawals, /api/mpesa, and
// /api/trading all 404'd regardless of what those files implemented.
app.use("/api/withdrawals", financialLimiter, withdrawalsRouter);
app.use("/api/mpesa", financialLimiter, mpesaRouter);
app.use("/api/trading", financialLimiter, tradingRouter);

app.use((_req, res) => {
  res.status(404).json({ error: "Not found" });
});

// Centralized error handler so an unexpected throw in any route returns a
// clean JSON error instead of an unhandled exception / raw stack trace.
app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(port, () => console.log(`Backend listening on ${port}`));
