import { Router } from "express";
import { AuthedRequest, requireAuth } from "../middleware/auth";
import { supabaseAdmin } from "../lib/supabase";
import { isValidPositiveAmount, isValidUuid } from "../lib/validation";
import { creditAccountBalance } from "../services/wallet/ledger";

export const mpesaRouter = Router();

/**
 * M-PESA Daraja boundary.
 *
 * This implements the request-validation, PENDING-deposit bookkeeping, and
 * idempotent-callback shape around Daraja — the parts that are safe to
 * write without production credentials. The actual OAuth token fetch and
 * STK push HTTP calls to Safaricom are left as a single clearly-marked
 * TODO: they need MPESA_CONSUMER_KEY/SECRET/SHORTCODE/PASSKEY (see
 * backend/.env.example) and a verified Daraja app before they can run for
 * real, and MPESA_ENVIRONMENT defaults to "sandbox" until then.
 */

async function daraja(_path: string, _body: unknown): Promise<{ CheckoutRequestID: string }> {
  if (!process.env.MPESA_CONSUMER_KEY || !process.env.MPESA_CONSUMER_SECRET) {
    throw new Error(
      "M-PESA is not configured. Set MPESA_CONSUMER_KEY/SECRET/SHORTCODE/PASSKEY " +
        "in backend/.env before initiating a real STK push."
    );
  }
  // TODO: implement OAuth token fetch + STK push call to the Daraja API
  // (sandbox or production depending on MPESA_ENVIRONMENT) here.
  throw new Error("Daraja STK push integration not yet implemented.");
}

mpesaRouter.post("/stkpush", requireAuth, async (req: AuthedRequest, res) => {
  const { accountId, amount, phone } = req.body ?? {};

  if (!isValidUuid(accountId)) return res.status(400).json({ error: "Invalid accountId" });
  if (!isValidPositiveAmount(amount)) return res.status(400).json({ error: "Invalid amount" });
  if (typeof phone !== "string" || !/^2547\d{8}$/.test(phone)) {
    return res.status(400).json({ error: "Invalid M-PESA phone (format 2547XXXXXXXX)" });
  }

  const { data: account, error: accountError } = await supabaseAdmin
    .from("accounts")
    .select("id,user_id,status")
    .eq("id", accountId)
    .single();

  if (accountError || !account || account.user_id !== req.userId) {
    return res.status(404).json({ error: "Account not found" });
  }
  if (account.status !== "ACTIVE") {
    return res.status(409).json({ error: "Account is not active" });
  }

  const { data: deposit, error: depositError } = await supabaseAdmin
    .from("deposits")
    .insert({
      user_id: req.userId,
      account_id: accountId,
      amount,
      status: "PENDING",
      provider: "mpesa",
    })
    .select()
    .single();

  if (depositError || !deposit) {
    return res.status(500).json({ error: "Failed to create deposit request" });
  }

  try {
    const stk = await daraja("stkpush", { amount, phone, accountReference: deposit.id });
    await supabaseAdmin
      .from("deposits")
      .update({ provider_reference: stk.CheckoutRequestID })
      .eq("id", deposit.id);
    return res.status(202).json({ deposit, checkoutRequestId: stk.CheckoutRequestID });
  } catch (err) {
    // Leave the deposit row as PENDING with no provider_reference — it is
    // simply not actionable until M-PESA is configured, not a broken record.
    return res.status(501).json({
      error: "M-PESA is not configured yet",
      detail: err instanceof Error ? err.message : String(err),
      deposit,
    });
  }
});

/**
 * Daraja calls this with the STK result. Safaricom may retry callbacks, so
 * this must be idempotent: `transactions.provider_reference` has a unique
 * index (see supabase/migrations/002_financial_core.sql), and we rely on
 * that constraint — not application logic alone — to guarantee a duplicate
 * callback can never credit twice.
 */
mpesaRouter.post("/callback", async (req, res) => {
  const checkoutRequestId: string | undefined = req.body?.Body?.stkCallback?.CheckoutRequestID;
  const resultCode: number | undefined = req.body?.Body?.stkCallback?.ResultCode;

  if (!checkoutRequestId) {
    return res.status(400).json({ error: "Malformed callback payload" });
  }

  const { data: deposit } = await supabaseAdmin
    .from("deposits")
    .select("*")
    .eq("provider_reference", checkoutRequestId)
    .single();

  if (!deposit) {
    return res.status(404).json({ error: "Unknown deposit for this callback" });
  }

  if (resultCode !== 0) {
    await supabaseAdmin.from("deposits").update({ status: "FAILED" }).eq("id", deposit.id);
    return res.json({ ok: true });
  }

  // Insert the ledger transaction first; the unique index on
  // provider_reference rejects a duplicate callback's second insert, so we
  // only credit the account once regardless of how many times Daraja
  // retries this callback.
  const { error: txError } = await supabaseAdmin.from("transactions").insert({
    user_id: deposit.user_id,
    account_id: deposit.account_id,
    type: "DEPOSIT",
    amount: deposit.amount,
    status: "COMPLETED",
    provider: "mpesa",
    provider_reference: checkoutRequestId,
  });

  if (txError) {
    // Unique-constraint violation = already processed; anything else is a
    // real failure worth surfacing to Safaricom as a retry-worthy error.
    if ((txError as { code?: string }).code === "23505") {
      return res.json({ ok: true, alreadyProcessed: true });
    }
    return res.status(500).json({ error: "Failed to record transaction" });
  }

  await supabaseAdmin
    .from("deposits")
    .update({ status: "COMPLETED" })
    .eq("id", deposit.id);

  await creditAccountBalance(deposit.account_id, Number(deposit.amount));

  res.json({ ok: true });
});
