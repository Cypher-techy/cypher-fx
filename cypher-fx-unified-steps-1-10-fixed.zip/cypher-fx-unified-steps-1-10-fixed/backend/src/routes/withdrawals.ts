import { Router } from "express";
import { AuthedRequest, requireAuth } from "../middleware/auth";
import { requireAdmin } from "../middleware/admin";
import { supabaseAdmin } from "../lib/supabase";
import { isValidPositiveAmount, isValidPhone, isValidUuid } from "../lib/validation";
import { lockWithdrawalFunds, unlockWithdrawalFunds } from "../services/wallet/ledger";

export const withdrawalsRouter = Router();

/**
 * Withdrawals always land as PENDING and require an admin approval step
 * before any payout is attempted — funds are never released on a user's
 * request alone. The actual M-PESA payout call (B2C) is intentionally not
 * implemented here: it requires production Daraja credentials and a
 * reviewed payout flow, not something to fabricate in a demo scaffold.
 */
withdrawalsRouter.post("/", requireAuth, async (req: AuthedRequest, res) => {
  const { accountId, amount, phone } = req.body ?? {};

  if (!isValidUuid(accountId)) return res.status(400).json({ error: "Invalid accountId" });
  if (!isValidPositiveAmount(amount)) return res.status(400).json({ error: "Invalid amount" });
  if (!isValidPhone(phone)) return res.status(400).json({ error: "Invalid M-PESA phone (format 2547XXXXXXXX)" });

  const { data: account, error: accountError } = await supabaseAdmin
    .from("accounts")
    .select("id,user_id,account_type,status")
    .eq("id", accountId)
    .single();

  if (accountError || !account || account.user_id !== req.userId) {
    return res.status(404).json({ error: "Account not found" });
  }
  if (account.status !== "ACTIVE") {
    return res.status(409).json({ error: "Account is not active" });
  }

  // Atomically move funds available -> locked. This closes a real race in
  // the original check-then-insert flow, where two concurrent requests
  // could both read a sufficient balance and both get approved before
  // either debited it, overdrawing the account.
  const locked = await lockWithdrawalFunds(accountId, Number(amount));
  if (!locked) {
    return res.status(400).json({ error: "Insufficient available balance" });
  }

  const { data: withdrawal, error } = await supabaseAdmin
    .from("withdrawals")
    .insert({
      user_id: req.userId,
      account_id: accountId,
      amount,
      destination_type: "MPESA",
      status: "PENDING",
    })
    .select()
    .single();

  if (error) {
    // Compensate: the row insert failed after funds were already locked,
    // so release them back to available_balance rather than stranding them.
    await unlockWithdrawalFunds(accountId, Number(amount));
    return res.status(500).json({ error: "Failed to create withdrawal request" });
  }

  res.status(201).json({ withdrawal });
});

withdrawalsRouter.get("/", requireAuth, async (req: AuthedRequest, res) => {
  const { data, error } = await supabaseAdmin
    .from("withdrawals")
    .select("*")
    .eq("user_id", req.userId)
    .order("created_at", { ascending: false });

  if (error) return res.status(500).json({ error: "Failed to load withdrawals" });
  res.json({ withdrawals: data });
});

/** Admin approval step — required before any payout can be initiated. */
withdrawalsRouter.post("/:id/approve", requireAuth, requireAdmin, async (req: AuthedRequest, res) => {
  const { data, error } = await supabaseAdmin
    .from("withdrawals")
    .update({ status: "APPROVED", approved_at: new Date().toISOString() })
    .eq("id", req.params.id)
    .eq("status", "PENDING")
    .select()
    .single();

  if (error || !data) return res.status(409).json({ error: "Withdrawal not found or not pending" });

  await supabaseAdmin.from("audit_logs").insert({
    actor_user_id: req.userId,
    action: "withdrawal.approve",
    entity_type: "withdrawal",
    entity_id: data.id,
  });

  res.json({ withdrawal: data });
});
