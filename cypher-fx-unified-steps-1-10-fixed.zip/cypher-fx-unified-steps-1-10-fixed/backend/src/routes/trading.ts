import { Router } from "express";
import { AuthedRequest, requireAuth } from "../middleware/auth";
import { supabaseAdmin } from "../lib/supabase";
import { isValidPositiveAmount, isValidSymbol, isValidUuid } from "../lib/validation";

export const tradingRouter = Router();

/**
 * Trading boundary.
 *
 * DEMO accounts: the order is filled immediately at the client-submitted
 * requestedPrice. This is a paper simulation only — there is no real
 * market data feed behind it, and the UI must label it DEMO.
 *
 * REAL accounts: orders are validated and stored as PENDING, then handed
 * to whichever provider TRADING_PROVIDER names. No such provider is wired
 * up in this scaffold, so real-account orders return 501 until one is
 * configured — this route will not fabricate a fill for real money.
 */
tradingRouter.post("/orders", requireAuth, async (req: AuthedRequest, res) => {
  const { accountId, symbol, side, quantity, requestedPrice } = req.body ?? {};

  if (!isValidUuid(accountId)) return res.status(400).json({ error: "Invalid accountId" });
  if (!isValidSymbol(symbol)) return res.status(400).json({ error: "Invalid symbol" });
  if (side !== "BUY" && side !== "SELL") return res.status(400).json({ error: "side must be BUY or SELL" });
  if (!isValidPositiveAmount(quantity)) return res.status(400).json({ error: "Invalid quantity" });
  if (!isValidPositiveAmount(requestedPrice)) {
    return res.status(400).json({ error: "Invalid requestedPrice" });
  }

  const { data: account, error: accountError } = await supabaseAdmin
    .from("accounts")
    .select("id,user_id,account_type,status")
    .eq("id", accountId)
    .single();

  if (accountError || !account || account.user_id !== req.userId) {
    return res.status(404).json({ error: "Account not found" });
  }
  if (account.status !== "ACTIVE") {
    return res.status(409).json({ error: "Account is not active" });
  }

  if (account.account_type === "DEMO") {
    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .insert({
        user_id: req.userId,
        account_id: accountId,
        symbol,
        side,
        order_type: "MARKET",
        quantity,
        requested_price: requestedPrice,
        filled_price: requestedPrice,
        filled_quantity: quantity,
        status: "FILLED",
      })
      .select()
      .single();

    if (error) return res.status(500).json({ error: "Failed to place demo order" });
    return res.status(201).json({ order, mode: "DEMO" });
  }

  // account_type === "REAL"
  if (!process.env.TRADING_PROVIDER || !process.env.TRADING_API_KEY) {
    return res.status(501).json({
      error:
        "No live trading provider is configured. Set TRADING_PROVIDER/TRADING_API_KEY/TRADING_API_SECRET " +
        "in backend/.env — this route intentionally will not simulate a real-money fill.",
    });
  }

  const { data: order, error } = await supabaseAdmin
    .from("orders")
    .insert({
      user_id: req.userId,
      account_id: accountId,
      symbol,
      side,
      order_type: "MARKET",
      quantity,
      requested_price: requestedPrice,
      status: "PENDING",
    })
    .select()
    .single();

  if (error) return res.status(500).json({ error: "Failed to place order" });

  // TODO: submit `order` to the configured TRADING_PROVIDER and update
  // status/filled_price/execution_id from its response once one is wired
  // up. Left unimplemented deliberately — see docstring above.
  res.status(202).json({ order, mode: "REAL", status: "awaiting execution provider" });
});

tradingRouter.get("/orders", requireAuth, async (req: AuthedRequest, res) => {
  const { data, error } = await supabaseAdmin
    .from("orders")
    .select("*")
    .eq("user_id", req.userId)
    .order("created_at", { ascending: false });

  if (error) return res.status(500).json({ error: "Failed to load orders" });
  res.json({ orders: data });
});
