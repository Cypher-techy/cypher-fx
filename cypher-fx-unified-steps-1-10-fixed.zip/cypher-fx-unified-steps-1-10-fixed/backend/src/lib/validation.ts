export const isValidPositiveAmount = (v: unknown): v is number => {
  const n = Number(v);
  return Number.isFinite(n) && n > 0;
};

export const isValidPhone = (v: unknown): v is string =>
  typeof v === "string" && /^2547\d{8}$/.test(v);

export const isValidSymbol = (v: unknown): v is string =>
  typeof v === "string" && /^[A-Z0-9._/-]{2,20}$/.test(v);

export const isValidUuid = (v: unknown): v is string =>
  typeof v === "string" &&
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
