import { createClient } from "@supabase/supabase-js";

const url = process.env.SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!url || !serviceRoleKey) {
  // Fail fast and loud rather than starting a backend that silently can't
  // reach the database — this key must never be exposed to the frontend.
  throw new Error(
    "Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY. Set both in backend/.env before starting the server."
  );
}

// Service-role client: bypasses RLS by design, so every route that uses
// this must apply its own authorization checks (see middleware/auth.ts and
// middleware/admin.ts) before touching user data.
export const supabaseAdmin = createClient(url, serviceRoleKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});
