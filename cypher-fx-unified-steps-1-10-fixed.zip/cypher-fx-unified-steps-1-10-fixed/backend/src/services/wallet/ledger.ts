import { supabaseAdmin } from "../../lib/supabase";

/**
 * Ledger boundary. Every balance mutation goes through a Postgres function
 * (see supabase/migrations/009_ledger_functions.sql) so it is atomic at the
 * database level — never a JS read-balance-then-write-balance sequence,
 * which would race under concurrent requests.
 */

export async function creditAccountBalance(accountId: string, amount: number): Promise<void> {
  const { error } = await supabaseAdmin.rpc("credit_account_balance", {
    p_account_id: accountId,
    p_amount: amount,
  });
  if (error) throw new Error(`Failed to credit account ${accountId}: ${error.message}`);
}

/** Returns false (instead of throwing) when the account has insufficient available balance. */
export async function lockWithdrawalFunds(accountId: string, amount: number): Promise<boolean> {
  const { data, error } = await supabaseAdmin.rpc("lock_withdrawal_funds", {
    p_account_id: accountId,
    p_amount: amount,
  });
  if (error) throw new Error(`Failed to lock withdrawal funds for ${accountId}: ${error.message}`);
  return Boolean(data);
}

export async function unlockWithdrawalFunds(accountId: string, amount: number): Promise<void> {
  const { error } = await supabaseAdmin.rpc("unlock_withdrawal_funds", {
    p_account_id: accountId,
    p_amount: amount,
  });
  if (error) throw new Error(`Failed to unlock withdrawal funds for ${accountId}: ${error.message}`);
}
