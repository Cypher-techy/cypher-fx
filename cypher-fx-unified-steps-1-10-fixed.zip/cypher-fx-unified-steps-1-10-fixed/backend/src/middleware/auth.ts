import { NextFunction, Request, Response } from "express";
import { supabaseAdmin } from "../lib/supabase";

export interface AuthedRequest extends Request {
  userId?: string;
  userEmail?: string;
}

/**
 * Verifies the Supabase-issued JWT sent as `Authorization: Bearer <token>`
 * and attaches the resolved user id to the request. Resource ownership
 * (does this user own this row?) is still each route's own responsibility —
 * this only proves who the caller is.
 */
export async function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  const token = header?.startsWith("Bearer ") ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: "Missing or invalid Authorization header" });
  }

  const { data, error } = await supabaseAdmin.auth.getUser(token);
  if (error || !data.user) {
    return res.status(401).json({ error: "Invalid or expired session" });
  }

  req.userId = data.user.id;
  req.userEmail = data.user.email ?? undefined;
  next();
}
