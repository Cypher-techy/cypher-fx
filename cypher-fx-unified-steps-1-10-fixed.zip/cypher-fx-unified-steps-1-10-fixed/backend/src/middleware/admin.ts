import { NextFunction, Response } from "express";
import { AuthedRequest } from "./auth";
import { supabaseAdmin } from "../lib/supabase";

/**
 * Verifies the caller's role server-side by reading `profiles.role` with
 * the service-role client — never trusts a client-supplied admin flag.
 * Must run after `requireAuth`.
 */
export async function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction) {
  if (!req.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }

  const { data, error } = await supabaseAdmin
    .from("profiles")
    .select("role")
    .eq("id", req.userId)
    .single();

  if (error || !data || data.role !== "admin") {
    return res.status(403).json({ error: "Admin access required" });
  }

  next();
}
