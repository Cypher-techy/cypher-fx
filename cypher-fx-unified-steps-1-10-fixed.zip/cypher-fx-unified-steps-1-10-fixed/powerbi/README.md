# Power BI
Use read-only reporting views. Never use a Supabase service-role key in Power BI. Pages: Executive Overview, Users & Accounts, Deposits, Withdrawals, Trading, Risk & Operations.