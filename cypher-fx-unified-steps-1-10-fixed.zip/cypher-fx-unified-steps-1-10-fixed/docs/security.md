# Security
Use RLS, server-side authorization, rate limiting, idempotency, audit logs, backups and reconciliation. Never collect an M-PESA PIN in the application.