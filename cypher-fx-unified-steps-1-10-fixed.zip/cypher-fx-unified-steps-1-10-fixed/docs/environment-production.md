# Production secrets
Frontend: NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY, NEXT_PUBLIC_API_URL.
Backend only: SUPABASE_SERVICE_ROLE_KEY, M-PESA secrets, trading API secrets. Never commit real credentials.