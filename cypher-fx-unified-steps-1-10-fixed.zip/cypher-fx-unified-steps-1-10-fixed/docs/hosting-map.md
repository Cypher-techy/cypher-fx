# Hosting map
frontend/ -> frontend host
backend/ -> backend/VPS/container host
supabase/ -> Supabase migrations/functions/database
powerbi/ -> Power BI reporting workspace
