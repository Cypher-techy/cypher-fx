# Security tests
- Unauthenticated protected request -> 401
- User A cannot access User B data
- Normal user cannot access admin endpoints
- Duplicate M-PESA callback cannot double-credit
- Invalid withdrawal rejected
- Browser cannot set final trade fill
- Service-role key never reaches browser
- Privileged actions create audit records
